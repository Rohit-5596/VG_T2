import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { HttpClient } from '@angular/common/http';
import { Investment } from '../models/investment';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  url: string = 'http://localhost:1111/invest';
  status: string;
  investService : Investment[] = [];

  constructor(private http: HttpClient) { 
    //this.getInvestors();
   }

  getData(): Observable<Investment> {
    return this.http.get<Investment>(this.url+'/b001');
  }
  postData(invest: Investment): Observable<Investment>
  {
 return this.http.post<Investment>(this.url+'/',invest);
  }


  /*getInvestors() {
    this.getData().subscribe((data: Investment[]) => {
       this.investService = data;
       console.log( this.investService);    
      });
  }

  getAllInvestors() {
    this.getInvestors()
    return this.investService;
  }*/
  addInvestor(investor: Investment)
  {
this.investService.push(investor);
return true;
  }

  statusCheck(i: number): void {
    console.log('painful'); 
  }
}
