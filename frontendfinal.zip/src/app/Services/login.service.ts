import { Injectable } from '@angular/core';
import { Investment } from '../models/investment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Login } from '../models/login';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  url: string = 'http://localhost:1111/login';
  status: string;
  loginService : Login;
  
  constructor(private http: HttpClient) { }

  postData(log: Login): Observable<Login> {
    
    return this.http.post<Login>(this.url+'/',log);
  }
}
