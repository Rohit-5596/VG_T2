import { Investment } from './investment';

describe('Investment', () => {
  it('should create an instance', () => {
    expect(new Investment()).toBeTruthy();
  });
});
