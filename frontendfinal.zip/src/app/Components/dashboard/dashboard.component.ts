import { Component, OnInit } from '@angular/core';
import { DashboardService } from 'src/app/Services/dashboard.service';
import { Investment } from 'src/app/models/investment';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  investor: Investment = { investmentId: '', pwd: '', income: 0, expenses: 0, asset: 0, lifeExpectancy: 0 };
  invest: Investment = { investmentId: '', pwd: '', income: 0, expenses: 0, asset: 0, lifeExpectancy: 0 };;
  constructor(private router: Router, private dashService: DashboardService) { }

  ngOnInit() {
    this.dashService.getData().subscribe(data => { this.investor = data; console.log(data) });
    console.log(this.investor + 'here');
  }
  add() {
    this.dashService.postData(this.investor).subscribe(data => { this.investor = data; console.log(data) });
    this.dashService.addInvestor(this.investor);
    alert('investor added successfully');
    //this.router.navigate(['dashboard']);
  }
  status(i: number) {
    if (confirm('The current status is "painful"')) {
      this.dashService.statusCheck(i);
    }

  }
}
