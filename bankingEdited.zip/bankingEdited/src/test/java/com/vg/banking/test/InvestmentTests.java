package com.vg.banking.test;

import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import static org.mockito.Mockito.when;

import com.vg.banking.dao.InvestmentRepo;
import com.vg.banking.dto.Investment;
import com.vg.banking.service.InvestmentService;
import com.vg.banking.service.InvestmentServiceImpl;
import org.junit.Assert;
import static org.mockito.Mockito.times;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;

public class InvestmentTests {
	
	Investment inv = new Investment();
	Investment invest = new Investment();

	@Test
	public void contextLoads() {

	}
	
	@InjectMocks
	InvestmentServiceImpl service;
	
	@Mock
	InvestmentRepo repo;
	
	@Spy
	List<Investment> list = new ArrayList<Investment>();
	
	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		 invest = new Investment("b001",3000,2000,200000,20);
		inv = new Investment("b001",3000,2000,200000,20);
		list.add(new Investment("b001",3000,2000,200000,20));
		}
	
	@Test
	public void findTest() {
		//service.resultById(inv);
		//verify(repo).findById("b001");

		when(repo.findAll()).thenReturn(list);
		Assert.assertEquals(true, service.resultById(inv));
		Assert.assertEquals(1, list.size());
		verify(list, times(1)).add(any(Investment.class));
	}
	
	@Test
	public void findAllTest() {
		when(repo.findAll()).thenReturn(list);
		
		ArrayList<Investment> iter = (ArrayList<Investment>) service.getInv();
		List<Investment> invList = new ArrayList<Investment>();
		iter.forEach(invList::add);
		Assert.assertEquals(1, invList.size());
		Assert.assertEquals(1, list.size());
		Assert.assertNotNull(iter);
	}
	
	@Test
	public void addTest()
	{
		when(repo.save(inv)).thenReturn(inv);
		assertEquals(repo.save(inv),inv);
	}
	
}
