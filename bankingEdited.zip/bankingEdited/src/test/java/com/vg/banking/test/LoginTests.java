package com.vg.banking.test;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

//import com.vg.banking.dao.InvestmentRepo;
import com.vg.banking.dao.LoginRepo;
import com.vg.banking.dto.Investment;
//import com.vg.banking.dto.Investment;
import com.vg.banking.dto.Login;
//import com.vg.banking.service.InvestmentServiceImpl;
import com.vg.banking.service.LoginServiceImpl;

public class LoginTests {
	
	Login log = new Login();
	

	@Test
	public void contextLoads() {

	}
	
	@InjectMocks
	LoginServiceImpl service;
	
	@Mock
	LoginRepo repo;
	
	@Spy
	List<Login> list = new ArrayList<Login>();
	
	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		 log = new Login("b001","john");
		//inv = new Investment("b001",3000,2000,200000,20);
		list.add(new Login("b001","john"));
		}

	@Test
	public void findAllTest() {
		when(repo.findAll()).thenReturn(list);
		
		ArrayList<Login> iter = (ArrayList<Login>) service.getUser();
		List<Login> logList = new ArrayList<Login>();
		iter.forEach(logList::add);
		Assert.assertEquals(1, logList.size());
		Assert.assertEquals(1, list.size());
		Assert.assertNotNull(iter);
	}
}
