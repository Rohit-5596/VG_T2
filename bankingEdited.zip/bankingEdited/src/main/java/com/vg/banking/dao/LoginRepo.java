package com.vg.banking.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.vg.banking.dto.Login;

@Repository
@Transactional
public interface LoginRepo extends JpaRepository<Login, String>{

}
