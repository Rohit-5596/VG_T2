package com.vg.banking.ctrl;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vg.banking.dto.Investment;
import com.vg.banking.dto.Login;
import com.vg.banking.service.InvestmentService;
import com.vg.banking.service.LoginService;

@RestController
@RequestMapping("/invest")
@CrossOrigin(origins = "http://localhost:4200")
public class InvestmentCtrl {
	
	
	@Autowired
	InvestmentService iService;
	
	@Autowired
	LoginService lService;
	
	
	@GetMapping(path = "/userDetails/")
	public List<Investment> getInv() {
		return iService.getInv() ;
	}
	
	@GetMapping(path = "/userCred/")
	public List<Login> getCred() {
		return lService.getUser() ;
	}
	
	@PostMapping(path = "/analyse/",consumes = "application/json")
	public boolean calc(@RequestBody Investment inv)
	{
		Investment newInv;
		newInv = iService.add(inv);
		return iService.resultById(newInv);
	}
	
	
}
