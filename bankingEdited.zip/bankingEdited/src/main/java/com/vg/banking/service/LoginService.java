package com.vg.banking.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.vg.banking.dto.Login;

@Service
public interface LoginService {
	
	public List<Login> getUser();
}
