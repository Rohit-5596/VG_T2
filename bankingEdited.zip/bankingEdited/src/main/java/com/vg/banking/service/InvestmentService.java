package com.vg.banking.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.vg.banking.dto.Investment;

@Service
public interface InvestmentService {
	
	public Investment add(Investment investment);
	
	
	public boolean resultById(Investment inv);


	public List<Investment> getInv();

}
