package com.vg.banking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vg.banking.dao.LoginRepo;
import com.vg.banking.dto.Login;

@Service
public class LoginServiceImpl implements LoginService{

	@Autowired
	LoginRepo lrepo ;

	@Override
	public List<Login> getUser() {
		return  lrepo.findAll();
	}

}
