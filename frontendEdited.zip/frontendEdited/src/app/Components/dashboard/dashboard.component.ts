import { Component, OnInit } from '@angular/core';
import { Investor } from 'src/app/model/investor';
import { MatDialogConfig, MatDialog } from '@angular/material/dialog';
import { LogoutComponent } from '../logout/logout.component';
import { DashboardService } from 'src/app/Services/dashboard.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  status: boolean;
  investor: Investor ={id:'', income:0, exp:0, asset:0, lifeExp:0};
  update: Investor;
  constructor(public matDialog: MatDialog,private dashService: DashboardService ) { }

  ngOnInit() {
    this.dashService.getData().subscribe(data => {this.investor = data[0]; console.log(data)});
    
  }

  openModal() {
    const dialogConfig = new MatDialogConfig();
    // The user can't close the dialog by clicking outside its body
    dialogConfig.disableClose = true;
    dialogConfig.id = "modal-component";
    dialogConfig.height = "350px";
    dialogConfig.width = "600px";
    // https://material.angular.io/components/dialog/overview
    const modalDialog = this.matDialog.open(LogoutComponent, dialogConfig);
  }

  add() {
    console.log(this.investor);
    this.status = this.dashService.analyse(this.investor);
    //alert("Database Updated successfully.");
    if( this.status == true){
      alert("Peacefull!!!");
    }
    else{
      alert("Painfull!!!");
    }


  };

}
