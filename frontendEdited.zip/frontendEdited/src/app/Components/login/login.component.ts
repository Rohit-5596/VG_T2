import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Login } from 'src/app/model/login';
import { LoginService } from 'src/app/Services/login.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  form: FormGroup;
  username: string;
  password: string;
  log: Login  ;
  

  constructor(private router: Router,private loginService: LoginService,private fb: FormBuilder) { }

  ngOnInit() {

    this.loginService.getData().subscribe(data => {this.log = data[0]; console.log(this.log)});

    this.form = this.fb.group({
      userName: ['',[Validators.required]],
      password: ['',[Validators.required]]
    });
  }

  login(){

    this.username = this.form.controls['userName'].value;
    this.password = this.form.controls['password'].value;

    if(this.username === this.log.investmentId && this.password === this.log.password){
      alert('logged in successfully');
      this.router.navigate(['/dashboard']);
    }
    else
    {
      console.log("unsuccessfull");
      alert('Invalid credentials');
    }
  }

  public hasError = (controlName: string, errorName: string) =>{
    return this.form.controls[controlName].hasError(errorName);
  }
  

}
