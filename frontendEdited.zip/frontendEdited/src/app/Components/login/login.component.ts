import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { LogoutComponent } from '../logout/logout.component';
import { Login } from 'src/app/model/login';
import { LoginService } from 'src/app/Services/login.service';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  userName: string;
  password: string;
  log: Login  ;
  

  constructor(private router: Router,private loginService: LoginService) { }

  ngOnInit() {

    this.loginService.getData().subscribe(data => {this.log = data[0]; console.log(this.log)});
  }

  login(){
    if(this.userName === this.log.investmentId && this.password === this.log.password){
      alert('logged in successfully');
      this.router.navigate(['/dashboard']);
    }
    else
    {
      console.log("unsuccessfull");
    }
  }

  

}
