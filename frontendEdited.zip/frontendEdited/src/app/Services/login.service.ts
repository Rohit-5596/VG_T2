import { Injectable } from '@angular/core';
import { Login } from '../model/login';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  url: string = 'http://localhost:1111/invest/userCred/';
  status: string;
  
  constructor(private http: HttpClient) { }

  getData(): Observable<Login[]> {
    return this.http.get<Login[]>(this.url);
  }

}
