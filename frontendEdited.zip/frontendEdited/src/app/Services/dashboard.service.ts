import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Investor } from '../model/investor';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
 
  
  fetchURL : string = 'http://localhost:1111/invest/userDetails/';
  postURL : string = 'http://localhost:1111/invest/analyse/';
  status: boolean;
  
  constructor(private http: HttpClient) { }

  getData(): Observable<Investor[]> {
    return this.http.get<Investor[]>(this.fetchURL);
  }

  analyse(investor: Investor) : boolean {
    //this.status = !this.status;
    this.http.post<any>(this.postURL, investor).subscribe(
      data  => {
       this.status = data;
      console.log("POST Request is successful ", data);
      },
      error  => {
      console.log("Error", error);
      }
      );
      //console.log(this.status);
      return this.status;
  }
}
