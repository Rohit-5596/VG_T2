export class Investor {

    id: string;
    income: number;
    exp: number;
    asset: number;
    lifeExp: number

}
