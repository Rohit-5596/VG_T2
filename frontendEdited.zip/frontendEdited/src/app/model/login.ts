export class Login {

    investmentId: string;
    password: string;
}
