import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatIconModule} from '@angular/material/icon';
import {MatMenuModule} from '@angular/material/menu';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatCardModule} from '@angular/material/card';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatTabsModule} from '@angular/material/tabs';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { MatInputModule} from '@angular/material/input';
import { MatDialogModule} from '@angular/material/dialog';

import { NgModule } from '@angular/core';

@NgModule({
    imports: [MatButtonModule, MatCheckboxModule, MatToolbarModule, MatIconModule, MatMenuModule,
        MatSidenavModule,MatCardModule, MatFormFieldModule, MatTabsModule, FormsModule, 
        HttpClientModule, MatInputModule, MatDialogModule],

    exports: [MatButtonModule, MatCheckboxModule, MatToolbarModule, MatIconModule, MatMenuModule, 
        MatSidenavModule,MatCardModule, MatFormFieldModule, MatTabsModule, FormsModule, HttpClientModule, 
        MatInputModule, MatDialogModule]
})

export class myOwnMaterialModule{

}